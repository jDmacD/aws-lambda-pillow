from OpenSSL.crypto import *
